package com.credit.decision.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.credit.decision.pojo.CreditRequest;
import com.credit.decision.pojo.CreditResponse;
import com.credit.decision.pojo.Response;



@Service
public class CreditDecisionService {
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${url.name}")
	String url;
	
	public Response getCreditScore(CreditRequest creditReq) throws Exception {
		
		Response response = new Response();
		CreditResponse cr = restTemplate.getForObject(url+"/"+creditReq.getSsnNumber(), CreditResponse.class);
		String d = cr.getCreditDate();
		if(Long.valueOf(creditReq.getSsnNumber()) != cr.getSsn() ){
			response.setSsnNumber(String.valueOf(cr.getSsn()));
		}else {
			throw new Exception("Applicant with same SSN Number can’t apply or try to apply for 30 days time");
		}
		if(Integer.parseInt(cr.getCreditScore())>700) {
			response.setSanctionAmount(creditReq.getCurrentAnnualIncome()/2);
		}
		
		return response;
	}
	
	public int getNumberOfDays(Date d){
		LocalDate endofCentury = LocalDate.of(d.getYear(), d.getMonth(), d.getDay());
		LocalDate now = LocalDate.now();
		Period diff = Period.between(endofCentury, now);
		return Integer.parseInt(diff.toString());
	}
}
