package com.credit.decision.pojo;

public class CreditRequest {

	
	private String ssnNumber;

	private Integer loanAmount;

	private Integer currentAnnualIncome;

	public String getSsnNumber() {
		return ssnNumber;
	}

	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}

	public Integer getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Integer getCurrentAnnualIncome() {
		return currentAnnualIncome;
	}

	public void setCurrentAnnualIncome(Integer currentAnnualIncome) {
		this.currentAnnualIncome = currentAnnualIncome;
	}

}
