package com.credit.decision.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.credit.decision.exception.ResourceNotFoundException;
import com.credit.decision.pojo.CreditRequest;
import com.credit.decision.pojo.Response;
import com.credit.decision.service.CreditDecisionService;


@RestController
@RequestMapping("/api")
public class CreditDecisionController {
	
	@Autowired
	CreditDecisionService creditDecisionService;
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello World";
	}
	
	@GetMapping("/getCreditScore")
    public Response  getScoreById(@RequestBody CreditRequest creditReq ) throws Exception {
		Response response = creditDecisionService.getCreditScore(creditReq);
        //return ResponseEntity.ok().body(cs);
       // return new ResponseEntity<CreditScore>(cs,HttpStatus.OK);
		//ResponseEntity<Response> responseEntity = new ResponseEntity<Response>(response, HttpStatus.OK);
		return response;
    }
	
	
	

}