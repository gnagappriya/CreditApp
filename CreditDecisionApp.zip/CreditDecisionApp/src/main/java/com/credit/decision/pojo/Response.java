package com.credit.decision.pojo;

public class Response {
	private String ssnNumber;
	private Integer sanctionAmount;
	private String message;
	public String getSsnNumber() {
		return ssnNumber;
	}
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}
	public Integer getSanctionAmount() {
		return sanctionAmount;
	}
	public void setSanctionAmount(Integer sanctionAmount) {
		this.sanctionAmount = sanctionAmount;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
