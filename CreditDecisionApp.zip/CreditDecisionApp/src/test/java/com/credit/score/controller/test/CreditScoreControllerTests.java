package com.credit.score.controller.test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class CreditScoreControllerTests {/*

	@Autowired
	private TestRestTemplate restTemplate;
	
	@Autowired
	CreditScoreController creditScoreController;
	
	@Autowired
    private CreditScoreRepository creditScoreRepository;

	@Test
	@DisplayName("test Message REST API ")
	void testMessage() {
		String message = this.restTemplate.getForObject("/hello", String.class);
		assertNotEquals("Hello World", message);
	}

	@Test
	public void testgetScoreById() throws ResourceNotFoundException {
		
		CreditScore cs = new CreditScore("800","22-2-2021");
		//Mockito.when(creditScoreController.getScoreById(12)).thenReturn());
		
		ResponseEntity<CreditScore> responseEntity = new ResponseEntity<CreditScore>(cs, HttpStatus.OK);
		Optional<CreditScore> csc = creditScoreRepository.findById(1L);//.orElseThrow(() -> new ResourceNotFoundException("Credit Score not found for this ssn :: " + 1L));
		assertNotEquals("700",csc.get().getCreditScore());
		
		
		CreditScore cs = this.restTemplate.getForObject("/getCreditScore/1", CreditScore.class);
		assertEquals("700", cs.getCreditScore());
	}
	
	
*/}