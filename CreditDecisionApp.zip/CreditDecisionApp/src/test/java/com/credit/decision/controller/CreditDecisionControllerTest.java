package com.credit.decision.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.credit.decision.pojo.CreditRequest;
import com.credit.decision.pojo.Response;
import com.credit.decision.service.CreditDecisionService;
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class CreditDecisionControllerTest {
	
	@InjectMocks
	CreditDecisionController creditDecisionController;
	
	@MockBean
	CreditDecisionService creditDecisionService;
	MockMvc mockMvc;
	
	
	static Response response;
	
	static ResponseEntity<Response> responseEntity ;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		response = new Response();
		response.setSsnNumber("145906767");
		response.setSanctionAmount(1000000);
		
	}

	@BeforeEach
	void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(creditDecisionController).build();
	}


	@Test
	void testGetScoreById() throws Exception {
		CreditRequest creditRequest = new CreditRequest();
		creditRequest.setSsnNumber("145906767");
		creditRequest.setLoanAmount(23434);
		creditRequest.setCurrentAnnualIncome(234234);
		Response response = new Response();
		response.setSsnNumber("145906767"); 
		Mockito.when(creditDecisionService.getCreditScore(creditRequest)).thenReturn(response);
		assertEquals("145906767", response.getSsnNumber());
		
	}

}
