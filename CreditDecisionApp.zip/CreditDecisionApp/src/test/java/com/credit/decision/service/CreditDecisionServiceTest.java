package com.credit.decision.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.credit.decision.pojo.CreditRequest;
import com.credit.decision.pojo.CreditResponse;
import com.credit.decision.pojo.Response;

class CreditDecisionServiceTest {
	@Mock
	CreditDecisionService creditDecisionService;
		
	@Mock
	RestTemplate restTemplate; 
	
	static Response response;
	
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		response = new Response();
		response.setSsnNumber("145906767");
		response.setSanctionAmount(1000000);
	}

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testGetCreditScore() throws Exception {
		CreditRequest creditRequest = new CreditRequest();
		creditRequest.setSsnNumber("145906767");
		creditRequest.setLoanAmount(23434);
		creditRequest.setCurrentAnnualIncome(234234);
		CreditResponse creditResponse= new CreditResponse();
		Mockito.when(restTemplate.getForObject("http://testUrl:8081/api/creditScore/121123211", CreditResponse.class)).thenReturn(creditResponse);
		Mockito.when(creditDecisionService.getCreditScore(creditRequest)).thenReturn(response);
		assertEquals("145906767", response.getSsnNumber());
	}

}
