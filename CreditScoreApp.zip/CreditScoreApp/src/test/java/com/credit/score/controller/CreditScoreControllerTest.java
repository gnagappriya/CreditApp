package com.credit.score.controller;





import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.credit.score.entity.CreditScore;
import com.credit.score.repository.CreditScoreRepository;

class CreditScoreControllerTest {
	@Mock
	CreditScoreController creditScoreController;
	
	@Mock
	CreditScoreRepository creditScoreRepository;
	
	

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	
	@Test
	void testGetScoreById() {
		CreditScore creditScore = new CreditScore();
		creditScore.setCreditDate("2021-2-2");
		creditScore.setSsn(123456789);
		creditScore.setCreditScore("700");
		Mockito.when( creditScoreRepository.findById(1L)).thenReturn(Optional.of(creditScore));
		//assertEquals("700", creditScore.getCreditScore());
		
	}

	@Test
	void testCreateCreditScore() {
		CreditScore creditScore = new CreditScore();
		creditScore.setCreditDate("2021-2-2");
		creditScore.setSsn(123456789);
		creditScore.setCreditScore("700");
		Mockito.when(creditScoreController.createCreditScore(creditScore)).thenReturn(creditScore);
		//assertEquals("700", creditScore.getCreditScore());
	}

}
