package com.credit.score.exception;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.context.request.WebRequest;
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class GlobalExceptionHandlerTest {

	@Mock
	 WebRequest request;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testResourceNotFoundException() {
		ErrorDetails errorDetails = new ErrorDetails(new Date(), "ResourceNotFoundException", request.getDescription(false));
		ResponseEntity re = new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		assertEquals("ResourceNotFoundException", errorDetails.getMessage());
	}

	@Test
	void testGlobleExcpetionHandler() {
		ErrorDetails errorDetails = new ErrorDetails(new Date(), "Exception", request.getDescription(false));
		ResponseEntity re = new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
		assertEquals("Exception", errorDetails.getMessage());
	}

}
