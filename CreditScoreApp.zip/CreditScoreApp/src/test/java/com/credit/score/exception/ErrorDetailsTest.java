package com.credit.score.exception;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ErrorDetailsTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

//	@Test
//	void testErrorDetails() {
//		ErrorDetails ed = new ErrorDetails(new Date(), "test message", "test details");
//		assertNotEquals(new Date().getTime(), ed.getTimestamp());	}

	@Test
	void testGetTimestamp() {
		ErrorDetails ed = new ErrorDetails(new Date(), "test message", "test details");
		assertNotEquals(new Date().getTime(), ed.getTimestamp());
	}

	@Test
	void testGetMessage() {
		ErrorDetails ed = new ErrorDetails(new Date(), "Hello", "test details");
		assertEquals("Hello", ed.getMessage());
	}

	@Test
	void testGetDetails() {
		ErrorDetails ed = new ErrorDetails(new Date(), "test message", "test details");
		assertNotEquals("test message", ed.getMessage());
	}

}
