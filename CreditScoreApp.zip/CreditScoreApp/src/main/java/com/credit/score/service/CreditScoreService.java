package com.credit.score.service;

import org.springframework.stereotype.Service;

@Service
public class CreditScoreService {

}
