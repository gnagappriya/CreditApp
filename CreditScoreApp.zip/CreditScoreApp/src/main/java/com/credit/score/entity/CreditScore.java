package com.credit.score.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "credit_score")
public class CreditScore {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long ssn;
	
	@Column(name="CREDIT_SCORE")
	String creditScore;
	
	@Column(name="CREDIT_DATE")
	private String creditDate;

	public CreditScore( String creditScore, String creditDate) {
		super();
		this.creditScore = creditScore;
		this.creditDate = creditDate;
	}

	public CreditScore() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	

	public long getSsn() {
		return ssn;
	}

	public void setSsn(long ssn) {
		this.ssn = ssn;
	}

	public String getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

	public String getCreditDate() {
		return creditDate;
	}

	public void setCreditDate(String creditDate) {
		this.creditDate = creditDate;
	}
	
	
}
