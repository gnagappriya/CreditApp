package com.credit.score.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.credit.score.entity.CreditScore;
import com.credit.score.exception.ResourceNotFoundException;
import com.credit.score.pojo.CreditResponse;
import com.credit.score.repository.CreditScoreRepository;


@RestController
@RequestMapping("/api")
public class CreditScoreController {
	
	@Autowired
    private CreditScoreRepository creditScoreRepository;

	@GetMapping("/hello")
	public String hello() {
		return "Hello World";
	}
	
	@GetMapping("/getCreditScore/{id}")
    public CreditResponse getScoreById(@PathVariable(value = "id") long id) throws ResourceNotFoundException {
		CreditScore cs = creditScoreRepository.findById(id).get();
           // .orElseThrow(() -> new ResourceNotFoundException("Credit Score not found for this ssn :: " + id));
		CreditResponse response = new CreditResponse();
		response.setSsn(cs.getSsn());
		response.setCreditScore(cs.getCreditScore());
		response.setCreditDate(cs.getCreditDate());
		return response;
    }
	
	@PostMapping("/saveCreditscore")
    public CreditScore createCreditScore(@Valid @RequestBody CreditScore creditScore) {
        return creditScoreRepository.save(creditScore);
    }

	

}