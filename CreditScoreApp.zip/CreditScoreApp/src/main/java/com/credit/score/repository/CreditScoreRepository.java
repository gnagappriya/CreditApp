package com.credit.score.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.credit.score.entity.CreditScore;
@Repository
public interface CreditScoreRepository extends JpaRepository<CreditScore, Long> {

}
